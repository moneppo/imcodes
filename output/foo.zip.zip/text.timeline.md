@00:00:
Ideas
-----

@00:02:
Ideas
-----
* Take over the world

@00:04:
Ideas
-----
* Take over the world
* Take over the solar system

@00:06:
Ideas
-----
* Take over the world
* Take over the solar system
* Take over the universe