@00:01:
import turtle

@00:04:
import turtle

t = turtle.Turtle()
    
@00:06:
import turtle

t = turtle.Turtle()

for c in ['red', 'green', 'yellow', 'blue']:
    t.color(c)
    t.forward(75)
    t.left(90)