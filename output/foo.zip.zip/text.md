Some Markdown
----

Isn't markdown neat?

I can even inline some code:
```
var foo = 2000;
foo -= 3;
console.log(foo);
```
